import React, { useState } from "react";
import { ScrollView, View, Text, Pressable, Alert } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useRouter } from "expo-router";
import * as Haptics from "expo-haptics";
import { CustomerSubscriptionService } from "@/lib/customer-subscription-service";
import { StripePaymentHandler } from "@/lib/stripe-payment-handler";
import { StripeCustomerService } from "@/lib/stripe-customer-service";

export default function CustomerSubscriptionScreen() {
  const router = useRouter();
  const [selectedPlan, setSelectedPlan] = useState<"monthly" | "yearly">("monthly");
  const [loading, setLoading] = useState(false);

  const handlePress = async () => {
    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const handleSubscribe = async () => {
    setLoading(true);
    handlePress();

    try {
      // Stripe payment flow:
      // 1. Create Stripe customer if needed
      const customerResult = await StripeCustomerService.createStripeCustomer({
        email: "customer@example.com", // In production, get from auth
        name: "Customer Name", // In production, get from auth
      });

      if (!customerResult.success || !customerResult.customerId) {
        Alert.alert("Error", "Failed to create customer account. Please try again.");
        setLoading(false);
        return;
      }

      // 2. Create payment intent
      const planDetails = StripePaymentHandler.getPlanDetails(selectedPlan);
      const paymentIntentResult = await StripeCustomerService.createPaymentIntent({
        customerId: customerResult.customerId,
        amount: StripePaymentHandler.formatAmount(planDetails.amount),
        plan: selectedPlan,
      });

      if (!paymentIntentResult.success || !paymentIntentResult.clientSecret) {
        Alert.alert("Error", "Failed to create payment. Please try again.");
        setLoading(false);
        return;
      }

      // 3. Initialize Stripe and confirm payment
      const publishableKey = StripeCustomerService.getPublishableKey();
      if (!publishableKey) {
        Alert.alert("Error", "Payment processor not configured. Please contact support.");
        setLoading(false);
        return;
      }

      const initResult = await StripePaymentHandler.initializePayment({
        publishableKey,
        clientSecret: paymentIntentResult.clientSecret,
        customerId: customerResult.customerId,
        amount: planDetails.amount,
        plan: selectedPlan,
      });

      if (!initResult.success) {
        Alert.alert("Error", StripePaymentHandler.getErrorMessage(initResult.errorCode));
        setLoading(false);
        return;
      }

      // 4. Confirm payment with Stripe.js
      const paymentResult = await StripePaymentHandler.confirmPayment({
        publishableKey,
        clientSecret: paymentIntentResult.clientSecret,
        customerId: customerResult.customerId,
        amount: planDetails.amount,
        plan: selectedPlan,
      });

      if (!paymentResult.success) {
        Alert.alert("Payment Failed", StripePaymentHandler.getErrorMessage(paymentResult.errorCode));
        setLoading(false);
        return;
      }

      // 5. Create subscription in database
      const subscriptionResult = await StripeCustomerService.createSubscription({
        customerId: customerResult.customerId,
        plan: selectedPlan,
        paymentMethodId: paymentIntentResult.subscriptionId || "pm_default",
      });

      if (!subscriptionResult.success) {
        Alert.alert("Error", "Failed to create subscription. Please contact support.");
        setLoading(false);
        return;
      }

      // Success! Navigate to payment success screen
      router.push("/customer-payment-success");
    } catch (error) {
      console.error("Subscription error:", error);
      Alert.alert("Error", "An unexpected error occurred. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScreenContainer>
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} className="flex-1">
        <View className="flex-1 gap-6 px-6 py-8">
          {/* Header */}
          <View className="gap-2">
            <Text className="text-4xl font-bold text-foreground">Join ClientCheck</Text>
            <Text className="text-base text-muted">
              Participate in fair, verified reviews of contractors
            </Text>
          </View>

          {/* Why Pay Section */}
          <View className="bg-blue-900/20 border border-blue-600/30 rounded-xl p-4 gap-3">
            <Text className="text-lg font-bold text-foreground">Why We Charge Both Sides</Text>
            <View className="gap-2">
              <View className="flex-row gap-3">
                <Text className="text-xl">🛡️</Text>
                <Text className="flex-1 text-sm text-muted">
                  <Text className="font-semibold text-foreground">Ensures Honest Reviews</Text> —
                  When both contractors and customers pay, everyone has skin in the game
                </Text>
              </View>
              <View className="flex-row gap-3">
                <Text className="text-xl">✅</Text>
                <Text className="flex-1 text-sm text-muted">
                  <Text className="font-semibold text-foreground">Prevents Fraud</Text> — Reduces
                  fake accounts and frivolous disputes
                </Text>
              </View>
              <View className="flex-row gap-3">
                <Text className="text-xl">⚖️</Text>
                <Text className="flex-1 text-sm text-muted">
                  <Text className="font-semibold text-foreground">Fair Moderation</Text> — Both
                  sides fund independent review process
                </Text>
              </View>
              <View className="flex-row gap-3">
                <Text className="text-xl">🔒</Text>
                <Text className="flex-1 text-sm text-muted">
                  <Text className="font-semibold text-foreground">Quality Community</Text> —
                  Committed members only
                </Text>
              </View>
            </View>
          </View>

          {/* Pricing Cards */}
          <View className="gap-3">
            <Text className="text-lg font-bold text-foreground">Choose Your Plan</Text>

            {/* Monthly */}
            <Pressable
              onPress={() => {
                handlePress();
                setSelectedPlan("monthly");
              }}
              style={({ pressed }) => [
                {
                  opacity: pressed ? 0.8 : 1,
                },
              ]}
              className={`border-2 rounded-xl p-4 gap-2 ${
                selectedPlan === "monthly"
                  ? "bg-primary/10 border-primary"
                  : "bg-surface border-border"
              }`}
            >
              <View className="flex-row items-center justify-between">
                <View className="gap-1">
                  <Text
                    className={`text-lg font-bold ${
                      selectedPlan === "monthly" ? "text-primary" : "text-foreground"
                    }`}
                  >
                    Monthly
                  </Text>
                  <Text className="text-sm text-muted">Flexible, cancel anytime</Text>
                </View>
                <View className="items-end gap-1">
                  <Text className="text-3xl font-bold text-foreground">$9.99</Text>
                  <Text className="text-xs text-muted">/month</Text>
                </View>
              </View>
            </Pressable>

            {/* Yearly */}
            <Pressable
              onPress={() => {
                handlePress();
                setSelectedPlan("yearly");
              }}
              style={({ pressed }) => [
                {
                  opacity: pressed ? 0.8 : 1,
                },
              ]}
              className={`border-2 rounded-xl p-4 gap-2 relative ${
                selectedPlan === "yearly"
                  ? "bg-green-900/10 border-green-500"
                  : "bg-surface border-border"
              }`}
            >
              <View className="absolute -top-3 right-4 bg-green-600 px-3 py-1 rounded-full">
                <Text className="text-xs font-bold text-white">
                  Save {CustomerSubscriptionService.YEARLY_SAVINGS}%
                </Text>
              </View>
              <View className="flex-row items-center justify-between">
                <View className="gap-1">
                  <Text
                    className={`text-lg font-bold ${
                      selectedPlan === "yearly" ? "text-green-500" : "text-foreground"
                    }`}
                  >
                    Yearly
                  </Text>
                  <Text className="text-sm text-muted">Best value, commit for a year</Text>
                </View>
                <View className="items-end gap-1">
                  <Text className="text-3xl font-bold text-foreground">$100</Text>
                  <Text className="text-xs text-muted">/year</Text>
                </View>
              </View>
            </Pressable>
          </View>

          {/* What You Get */}
          <View className="bg-surface border border-border rounded-xl p-4 gap-3">
            <Text className="font-bold text-foreground">What's Included</Text>
            <View className="gap-2">
              <Text className="text-sm text-muted">✓ View all contractor reviews and ratings</Text>
              <Text className="text-sm text-muted">✓ Respond to reviews about your business</Text>
              <Text className="text-sm text-muted">✓ File disputes with evidence</Text>
              <Text className="text-sm text-muted">✓ Track your reputation score</Text>
              <Text className="text-sm text-muted">✓ Priority support</Text>
            </View>
          </View>

          {/* Fair Reviews Message */}
          <View className="bg-yellow-900/20 border border-yellow-600/30 rounded-lg p-4">
            <Text className="text-xs text-muted leading-relaxed">
              <Text className="font-semibold">Our Commitment:</Text> Both contractors and customers
              pay equally. This ensures fair moderation, prevents fake reviews, and creates a
              trusted community where honest feedback matters.
            </Text>
          </View>

          {/* Subscribe Button */}
          <Pressable
            onPress={handleSubscribe}
            disabled={loading}
            style={({ pressed }) => [
              {
                opacity: pressed ? 0.8 : 1,
                transform: [{ scale: pressed ? 0.97 : 1 }],
              },
            ]}
            className={`py-4 px-6 rounded-lg items-center ${
              loading ? "bg-primary/50" : "bg-primary"
            }`}
          >
            <Text className="text-white font-bold text-lg">
              {loading
                ? "Processing..."
                : `Subscribe to ${selectedPlan === "monthly" ? "Monthly" : "Yearly"} Plan`}
            </Text>
          </Pressable>

          {/* Footer */}
          <View className="items-center gap-2">
            <Text className="text-xs text-muted">
              Non-refundable annual subscription • Cancel monthly anytime
            </Text>
            <Pressable onPress={() => router.back()}>
              <Text className="text-sm text-primary font-semibold">Back</Text>
            </Pressable>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
