import React, { useState, useEffect } from "react";
import { ScrollView, View, Text, Pressable, FlatList, ActivityIndicator } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useRouter } from "expo-router";
import * as Haptics from "expo-haptics";
import { EmailNotificationService } from "@/lib/email-notification-service";

interface Notification {
  id: string;
  type: string;
  subject: string;
  recipient: string;
  sentAt: number;
  status: "sent" | "failed" | "pending";
}

export default function NotificationHistoryScreen() {
  const router = useRouter();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<"all" | "sent" | "failed">("all");

  const handlePress = async () => {
    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  useEffect(() => {
    loadNotifications();
  }, []);

  const loadNotifications = async () => {
    try {
      setLoading(true);
      // In production, fetch from API
      // const result = await api.get('/notifications/history');
      // setNotifications(result.data);

      // Simulate loading
      await new Promise((resolve) => setTimeout(resolve, 800));

      // Mock data
      const mockNotifications: Notification[] = [
        {
          id: "1",
          type: "review_posted",
          subject: "New Review from John Smith",
          recipient: "jane@example.com",
          sentAt: Date.now() - 1000 * 60 * 5, // 5 minutes ago
          status: "sent",
        },
        {
          id: "2",
          type: "weekly_summary",
          subject: "Your Weekly Review Summary",
          recipient: "jane@example.com",
          sentAt: Date.now() - 1000 * 60 * 60 * 24, // 1 day ago
          status: "sent",
        },
        {
          id: "3",
          type: "dispute_filed",
          subject: "Dispute Filed Against Your Review",
          recipient: "john@example.com",
          sentAt: Date.now() - 1000 * 60 * 60 * 48, // 2 days ago
          status: "sent",
        },
        {
          id: "4",
          type: "payment_received",
          subject: "Payment Received - Subscription Confirmed",
          recipient: "jane@example.com",
          sentAt: Date.now() - 1000 * 60 * 60 * 72, // 3 days ago
          status: "sent",
        },
        {
          id: "5",
          type: "review_rejected",
          subject: "Review Rejected - Please Review",
          recipient: "john@example.com",
          sentAt: Date.now() - 1000 * 60 * 60 * 96, // 4 days ago
          status: "failed",
        },
      ];

      setNotifications(mockNotifications);
    } catch (error) {
      console.error("Failed to load notifications:", error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status: string) => {
    if (status === "sent") return "text-green-400";
    if (status === "failed") return "text-red-400";
    return "text-yellow-400";
  };

  const getStatusIcon = (status: string) => {
    if (status === "sent") return "✓";
    if (status === "failed") return "✕";
    return "⏳";
  };

  const getTimeAgo = (timestamp: number): string => {
    const now = Date.now();
    const diff = now - timestamp;
    const seconds = Math.floor(diff / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    if (days > 0) return `${days}d ago`;
    if (hours > 0) return `${hours}h ago`;
    if (minutes > 0) return `${minutes}m ago`;
    return "just now";
  };

  const filteredNotifications =
    filter === "all"
      ? notifications
      : notifications.filter((n) => n.status === filter);

  const renderNotificationItem = ({ item }: { item: Notification }) => (
    <Pressable
      onPress={() => handlePress()}
      className="bg-surface border border-border rounded-lg p-4 mb-3 flex-row justify-between items-start gap-3"
    >
      <View className="flex-1 gap-2">
        <View className="flex-row justify-between items-start gap-2">
          <Text className="text-sm font-bold text-foreground flex-1">
            {EmailNotificationService.getNotificationTypeName(item.type)}
          </Text>
          <Text className={`text-xs font-semibold ${getStatusColor(item.status)}`}>
            {getStatusIcon(item.status)} {item.status}
          </Text>
        </View>

        <Text className="text-sm text-muted line-clamp-2">{item.subject}</Text>

        <View className="flex-row justify-between items-center gap-2">
          <Text className="text-xs text-muted">{item.recipient}</Text>
          <Text className="text-xs text-muted">{getTimeAgo(item.sentAt)}</Text>
        </View>
      </View>
    </Pressable>
  );

  return (
    <ScreenContainer>
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} className="flex-1">
        <View className="flex-1 gap-4 px-6 py-8">
          {/* Header */}
          <View className="gap-2">
            <Text className="text-4xl font-bold text-foreground">Notification History</Text>
            <Text className="text-base text-muted">View your sent notifications</Text>
          </View>

          {/* Stats */}
          <View className="bg-surface border border-border rounded-lg p-4 gap-2">
            <Text className="text-sm font-bold text-foreground">
              {filteredNotifications.length} Notification{filteredNotifications.length !== 1 ? "s" : ""}
            </Text>
            <View className="flex-row gap-2">
              <View className="flex-1 items-center py-2">
                <Text className="text-xs text-muted">Sent</Text>
                <Text className="text-lg font-bold text-green-400">
                  {notifications.filter((n) => n.status === "sent").length}
                </Text>
              </View>
              <View className="flex-1 items-center py-2 border-l border-border">
                <Text className="text-xs text-muted">Failed</Text>
                <Text className="text-lg font-bold text-red-400">
                  {notifications.filter((n) => n.status === "failed").length}
                </Text>
              </View>
              <View className="flex-1 items-center py-2 border-l border-border">
                <Text className="text-xs text-muted">Pending</Text>
                <Text className="text-lg font-bold text-yellow-400">
                  {notifications.filter((n) => n.status === "pending").length}
                </Text>
              </View>
            </View>
          </View>

          {/* Filter Buttons */}
          <View className="flex-row gap-2">
            {(["all", "sent", "failed"] as const).map((f) => (
              <Pressable
                key={f}
                onPress={() => {
                  handlePress();
                  setFilter(f);
                }}
                className={`px-4 py-2 rounded-lg ${
                  filter === f ? "bg-primary" : "bg-surface border border-border"
                }`}
              >
                <Text
                  className={`text-sm font-semibold ${
                    filter === f ? "text-white" : "text-foreground"
                  }`}
                >
                  {f === "all" ? "All" : f === "sent" ? "Sent" : "Failed"}
                </Text>
              </Pressable>
            ))}
          </View>

          {/* Loading State */}
          {loading && (
            <View className="py-8 items-center">
              <ActivityIndicator size="large" color="#0a7ea4" />
              <Text className="text-muted mt-2">Loading notifications...</Text>
            </View>
          )}

          {/* Notifications List */}
          {!loading && filteredNotifications.length > 0 && (
            <FlatList
              data={filteredNotifications}
              keyExtractor={(item) => item.id}
              renderItem={renderNotificationItem}
              scrollEnabled={false}
            />
          )}

          {/* Empty State */}
          {!loading && filteredNotifications.length === 0 && (
            <View className="flex-1 items-center justify-center gap-4">
              <Text className="text-6xl">📭</Text>
              <Text className="text-lg font-bold text-foreground">No Notifications</Text>
              <Text className="text-sm text-muted text-center">
                You don't have any {filter !== "all" ? filter : ""} notifications yet
              </Text>
            </View>
          )}

          {/* Info Banner */}
          <View className="bg-blue-900/20 border border-blue-600/30 rounded-lg p-4 mt-6">
            <Text className="text-sm text-blue-300">
              💡 Notifications are kept for 90 days. Manage your notification preferences in
              Settings.
            </Text>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
