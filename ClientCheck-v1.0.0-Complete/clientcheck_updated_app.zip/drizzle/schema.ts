import {
  boolean,
  decimal,
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Contractor profiles — extended info for contractors using the app.
 */
export const contractorProfiles = mysqlTable("contractor_profiles", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  trade: varchar("trade", { length: 128 }),
  licenseNumber: varchar("licenseNumber", { length: 64 }),
  company: varchar("company", { length: 255 }),
  city: varchar("city", { length: 128 }),
  state: varchar("state", { length: 64 }),
  bio: text("bio"),
  verificationStatus: mysqlEnum("verificationStatus", ["unverified", "pending", "verified", "rejected"]).default("unverified").notNull(),
  idVerified: boolean("idVerified").default(false).notNull(),
  licenseVerified: boolean("licenseVerified").default(false).notNull(),
  insuranceVerified: boolean("insuranceVerified").default(false).notNull(),
  idDocumentUrl: varchar("idDocumentUrl", { length: 512 }),
  licenseDocumentUrl: varchar("licenseDocumentUrl", { length: 512 }),
  insuranceDocumentUrl: varchar("insuranceDocumentUrl", { length: 512 }),
  verificationSubmittedAt: timestamp("verificationSubmittedAt"),
  verificationReviewedAt: timestamp("verificationReviewedAt"),
  verificationNotes: text("verificationNotes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ContractorProfile = typeof contractorProfiles.$inferSelect;
export type InsertContractorProfile = typeof contractorProfiles.$inferInsert;

/**
 * Customer profiles — the people being vetted by contractors.
 */
export const customers = mysqlTable("customers", {
  id: int("id").autoincrement().primaryKey(),
  firstName: varchar("firstName", { length: 128 }).notNull(),
  lastName: varchar("lastName", { length: 128 }).notNull(),
  phone: varchar("phone", { length: 32 }).notNull().unique(),
  email: varchar("email", { length: 320 }),
  address: varchar("address", { length: 255 }).notNull(),
  city: varchar("city", { length: 128 }).notNull(),
  state: varchar("state", { length: 64 }).notNull(),
  zip: varchar("zip", { length: 16 }).notNull(),
  mergedIntoId: int("mergedIntoId"),
  isDuplicate: boolean("isDuplicate").default(false).notNull(),
  // Aggregate rating fields (denormalized for fast reads)
  overallRating: decimal("overallRating", { precision: 3, scale: 2 }).default("0.00"),
  reviewCount: int("reviewCount").default(0).notNull(),
  ratingPaymentReliability: decimal("ratingPaymentReliability", { precision: 3, scale: 2 }).default("0.00"),
  ratingCommunication: decimal("ratingCommunication", { precision: 3, scale: 2 }).default("0.00"),
  ratingScopeChanges: decimal("ratingScopeChanges", { precision: 3, scale: 2 }).default("0.00"),
  ratingPropertyRespect: decimal("ratingPropertyRespect", { precision: 3, scale: 2 }).default("0.00"),
  ratingPermitPulling: decimal("ratingPermitPulling", { precision: 3, scale: 2 }).default("0.00"),
  ratingOverallJobExperience: decimal("ratingOverallJobExperience", { precision: 3, scale: 2 }).default("0.00"),
  // Risk level computed from overallRating
  riskLevel: mysqlEnum("riskLevel", ["low", "medium", "high", "unknown"]).default("unknown").notNull(),
  createdByUserId: int("createdByUserId").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Customer = typeof customers.$inferSelect;
export type InsertCustomer = typeof customers.$inferInsert;

/**
 * Reviews — a contractor's rating and review of a customer.
 */
export const reviews = mysqlTable("reviews", {
  id: int("id").autoincrement().primaryKey(),
  customerId: int("customerId").notNull(),
  contractorUserId: int("contractorUserId").notNull(),
  // Overall star rating 1–5
  overallRating: int("overallRating").notNull(),
  // Category ratings 1–5 (new consolidated categories)
  ratingPaymentReliability: int("ratingPaymentReliability").notNull(),
  ratingCommunication: int("ratingCommunication").notNull(),
  ratingScopeChanges: int("ratingScopeChanges").notNull(),
  ratingPropertyRespect: int("ratingPropertyRespect").notNull(),
  ratingPermitPulling: int("ratingPermitPulling").notNull(),
  ratingOverallJobExperience: int("ratingOverallJobExperience").notNull(),
  clientScore: int("clientScore").default(0).notNull(),
  confirmationCount: int("confirmationCount").default(0).notNull(),
  // Review text
  reviewText: text("reviewText"),
  // Job details
  jobType: varchar("jobType", { length: 128 }),
  jobDate: varchar("jobDate", { length: 32 }),
  jobAmount: varchar("jobAmount", { length: 32 }),
  // Red flags (stored as comma-separated string for simplicity)
  redFlags: text("redFlags"),
  // Helpful votes
  helpfulCount: int("helpfulCount").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Review = typeof reviews.$inferSelect;
export type InsertReview = typeof reviews.$inferInsert;

/**
 * Helpful votes — tracks which contractors found a review helpful.
 */
export const reviewHelpfulVotes = mysqlTable("review_helpful_votes", {
  id: int("id").autoincrement().primaryKey(),
  reviewId: int("reviewId").notNull(),
  userId: int("userId").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ReviewHelpfulVote = typeof reviewHelpfulVotes.$inferSelect;

/**
 * Subscriptions — tracks user subscription status and trial periods.
 */
export const subscriptions = mysqlTable("subscriptions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  status: mysqlEnum("status", ["trial", "active", "cancelled", "expired"]).default("trial").notNull(),
  trialStartedAt: timestamp("trialStartedAt").defaultNow().notNull(),
  trialEndsAt: timestamp("trialEndsAt").notNull(),
  subscriptionStartedAt: timestamp("subscriptionStartedAt"),
  subscriptionEndsAt: timestamp("subscriptionEndsAt"),
  // For now, we'll store payment info as null (manual payment tracking)
  // In production, integrate with Stripe or similar
  paymentMethod: varchar("paymentMethod", { length: 64 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Subscription = typeof subscriptions.$inferSelect;
export type InsertSubscription = typeof subscriptions.$inferInsert;

/**
 * Review photos — images attached to reviews for evidence/documentation.
 */
export const reviewPhotos = mysqlTable("review_photos", {
  id: int("id").autoincrement().primaryKey(),
  reviewId: int("reviewId").notNull(),
  photoUrl: text("photoUrl").notNull(), // S3 or storage URL
  caption: text("caption"), // Optional caption for the photo
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ReviewPhoto = typeof reviewPhotos.$inferSelect;
export type InsertReviewPhoto = typeof reviewPhotos.$inferInsert;

/**
 * Review disputes — customers can dispute negative reviews with their own response.
 */
export const reviewDisputes = mysqlTable("review_disputes", {
  id: int("id").autoincrement().primaryKey(),
  reviewId: int("reviewId").notNull(),
  customerId: int("customerId").notNull(),
  status: mysqlEnum("status", ["open", "responded", "resolved", "dismissed"]).default("open").notNull(),
  customerResponse: text("customerResponse"), // Customer's written response to the review
  respondedAt: timestamp("respondedAt"),
  resolvedAt: timestamp("resolvedAt"),
  resolution: text("resolution"), // Admin/moderator resolution notes
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ReviewDispute = typeof reviewDisputes.$inferSelect;
export type InsertReviewDispute = typeof reviewDisputes.$inferInsert;

/**
 * Dispute photos — customer response photos for disputes.
 */
export const disputePhotos = mysqlTable("dispute_photos", {
  id: int("id").autoincrement().primaryKey(),
  disputeId: int("disputeId").notNull(),
  photoUrl: varchar("photoUrl", { length: 512 }).notNull(),
  uploadedAt: timestamp("uploadedAt").defaultNow().notNull(),
});

export type DisputePhoto = typeof disputePhotos.$inferSelect;
export type InsertDisputePhoto = typeof disputePhotos.$inferInsert;

/**
 * Review moderation queue — admins review flagged reviews before they appear publicly.
 */
export const reviewModerations = mysqlTable("review_moderations", {
  id: int("id").autoincrement().primaryKey(),
  reviewId: int("reviewId").notNull(),
  status: mysqlEnum("status", ["pending", "approved", "rejected", "request_changes"]).default("pending").notNull(),
  reason: text("reason"), // Reason for flagging (if rejected or request_changes)
  moderatorId: int("moderatorId"), // Admin who reviewed it
  moderatedAt: timestamp("moderatedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ReviewModeration = typeof reviewModerations.$inferSelect;
export type InsertReviewModeration = typeof reviewModerations.$inferInsert;

/**
 * Contractor analytics — aggregated stats for contractor dashboard.
 */
export const contractorAnalytics = mysqlTable("contractor_analytics", {
  id: int("id").autoincrement().primaryKey(),
  contractorUserId: int("contractorUserId").notNull(),
  totalReviewsSubmitted: int("totalReviewsSubmitted").default(0).notNull(),
  totalDisputesReceived: int("totalDisputesReceived").default(0).notNull(),
  totalDisputesResponded: int("totalDisputesResponded").default(0).notNull(),
  disputeResponseRate: decimal("disputeResponseRate", { precision: 5, scale: 2 }).default("0").notNull(), // 0-100%
  averageReputationScore: decimal("averageReputationScore", { precision: 3, scale: 1 }).default("0").notNull(), // 0-10
  mostCommonRedFlag: varchar("mostCommonRedFlag", { length: 128 }),
  redFlagCounts: text("redFlagCounts"), // JSON: { "slow_payer": 5, "disputed_invoice": 3, ... }
  reviewsThisMonth: int("reviewsThisMonth").default(0).notNull(),
  reviewsLastMonth: int("reviewsLastMonth").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ContractorAnalytics = typeof contractorAnalytics.$inferSelect;
export type InsertContractorAnalytics = typeof contractorAnalytics.$inferInsert;

/**
 * Email notifications log — track sent emails for audit and retry purposes.
 */
export const emailNotifications = mysqlTable("email_notifications", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  type: mysqlEnum("type", [
    "trial_expiring_7_days",
    "trial_expiring_1_day",
    "trial_expired",
    "dispute_filed",
    "review_posted",
    "review_approved",
    "review_rejected",
  ]).notNull(),
  recipientEmail: varchar("recipientEmail", { length: 320 }).notNull(),
  status: mysqlEnum("status", ["pending", "sent", "failed"]).default("pending").notNull(),
  sentAt: timestamp("sentAt"),
  failureReason: text("failureReason"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type EmailNotification = typeof emailNotifications.$inferSelect;
export type InsertEmailNotification = typeof emailNotifications.$inferInsert;


/**
 * In-app messages between users
 */
export const messages = mysqlTable("messages", {
  id: int("id").autoincrement().primaryKey(),
  senderId: int("senderId").notNull(),
  recipientId: int("recipientId").notNull(),
  text: text("text").notNull(),
  read: boolean("read").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Message = typeof messages.$inferSelect;
export type InsertMessage = typeof messages.$inferInsert;

/**
 * Onboarding status tracking
 */
export const onboardingStatus = mysqlTable("onboarding_status", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  profileCompleted: boolean("profileCompleted").default(false).notNull(),
  tradeSelected: boolean("tradeSelected").default(false).notNull(),
  verificationSubmitted: boolean("verificationSubmitted").default(false).notNull(),
  completedAt: timestamp("completedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type OnboardingStatus = typeof onboardingStatus.$inferSelect;
export type InsertOnboardingStatus = typeof onboardingStatus.$inferInsert;


/**
 * Achievements - gamification badges for contractors
 */
export const achievements = mysqlTable("achievements", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  type: mysqlEnum("type", [
    "TOP_VETTER",
    "PAYMENT_DETECTIVE",
    "RED_FLAG_SPOTTER",
    "COMMUNITY_HELPER",
    "ACCURACY_MASTER",
    "STREAK_7",
    "STREAK_30",
    "REVIEWS_10",
    "REVIEWS_50",
    "REVIEWS_100"
  ]).notNull(),
  title: varchar("title", { length: 128 }).notNull(),
  description: text("description"),
  unlockedAt: timestamp("unlockedAt").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Achievement = typeof achievements.$inferSelect;
export type InsertAchievement = typeof achievements.$inferInsert;

/**
 * Contractor streaks - daily vetting engagement
 */
export const contractorStreaks = mysqlTable("contractor_streaks", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  currentStreak: int("currentStreak").default(0).notNull(),
  longestStreak: int("longestStreak").default(0).notNull(),
  lastActivityDate: timestamp("lastActivityDate"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ContractorStreak = typeof contractorStreaks.$inferSelect;
export type InsertContractorStreak = typeof contractorStreaks.$inferInsert;

/**
 * Referral tracking - viral growth incentives
 */
export const referrals = mysqlTable("referrals", {
  id: int("id").autoincrement().primaryKey(),
  referrerId: int("referrerId").notNull(),
  referredUserId: int("referredUserId"),
  referralCode: varchar("referralCode", { length: 32 }).notNull().unique(),
  referralEmail: varchar("referralEmail", { length: 320 }),
  status: mysqlEnum("status", ["pending", "completed", "expired"]).default("pending").notNull(),
  rewardUnlocked: boolean("rewardUnlocked").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  completedAt: timestamp("completedAt"),
  expiresAt: timestamp("expiresAt").notNull(),
});

export type Referral = typeof referrals.$inferSelect;
export type InsertReferral = typeof referrals.$inferInsert;

/**
 * Customer risk timeline - intelligence dashboard
 */
export const customerRiskTimeline = mysqlTable("customer_risk_timeline", {
  id: int("id").autoincrement().primaryKey(),
  customerId: int("customerId").notNull(),
  eventType: mysqlEnum("eventType", ["payment_delay", "scope_creep", "dispute", "negative_review", "positive_review"]).notNull(),
  description: text("description"),
  severity: mysqlEnum("severity", ["low", "medium", "high"]).default("medium").notNull(),
  relatedReviewId: int("relatedReviewId"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type CustomerRiskTimeline = typeof customerRiskTimeline.$inferSelect;
export type InsertCustomerRiskTimeline = typeof customerRiskTimeline.$inferInsert;

/**
 * Customer alerts - custom notifications for contractors
 */
export const customerAlerts = mysqlTable("customer_alerts", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  customerId: int("customerId").notNull(),
  alertType: mysqlEnum("alertType", ["multiple_red_flags", "payment_pattern", "dispute_activity", "high_risk_score"]).notNull(),
  threshold: int("threshold").default(3).notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type CustomerAlert = typeof customerAlerts.$inferSelect;
export type InsertCustomerAlert = typeof customerAlerts.$inferInsert;

/**
 * Contractor connections - network graph
 */
export const contractorConnections = mysqlTable("contractor_connections", {
  id: int("id").autoincrement().primaryKey(),
  contractorId: int("contractorId").notNull(),
  connectedContractorId: int("connectedContractorId").notNull(),
  connectionType: mysqlEnum("connectionType", ["same_trade", "same_location", "referral", "collaboration"]).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ContractorConnection = typeof contractorConnections.$inferSelect;
export type InsertContractorConnection = typeof contractorConnections.$inferInsert;

/**
 * Call logs - track incoming calls and customer interactions
 */
export const callLogs = mysqlTable("call_logs", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  customerId: int("customerId"),
  phoneNumber: varchar("phoneNumber", { length: 32 }).notNull(),
  callType: mysqlEnum("callType", ["incoming", "outgoing", "missed"]).notNull(),
  callDuration: int("callDuration"),
  callOutcome: mysqlEnum("callOutcome", ["accepted", "declined", "missed"]),
  reviewSubmitted: boolean("reviewSubmitted").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type CallLog = typeof callLogs.$inferSelect;
export type InsertCallLog = typeof callLogs.$inferInsert;
/**
 * Contractor verification badges - admins manually verify contractors and assign badges to reviews
 */
export const contractorVerificationBadges = mysqlTable("contractor_verification_badges", {
  id: int("id").autoincrement().primaryKey(),
  reviewId: int("reviewId").notNull().unique(),
  contractorUserId: int("contractorUserId").notNull(),
  licenseNumber: varchar("licenseNumber", { length: 64 }).notNull(),
  state: varchar("state", { length: 64 }).notNull(),
  verifiedByAdminId: int("verifiedByAdminId").notNull(),
  verificationNotes: text("verificationNotes"),
  verifiedAt: timestamp("verifiedAt").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ContractorVerificationBadge = typeof contractorVerificationBadges.$inferSelect;
export type InsertContractorVerificationBadge = typeof contractorVerificationBadges.$inferInsert;
