import { Platform } from "react-native";

// Dynamically import RNCallDetection to avoid issues on non-Android platforms
let RNCallDetection: any = null;
if (Platform.OS === "android") {
  try {
    RNCallDetection = require("react-native-call-detection");
  } catch (e) {
    console.warn("react-native-call-detection not available");
  }
}

export interface IncomingCall {
  phoneNumber: string;
  displayName?: string;
  callType: "incoming" | "outgoing" | "missed";
}

export interface CallDetectionListener {
  onIncomingCall: (call: IncomingCall) => void;
  onCallEnded: () => void;
}

let callDetectionSubscription: any = null;

/**
 * Start listening for incoming calls
 * Works on Android and iOS (with limitations)
 */
export function startCallDetection(listener: CallDetectionListener): void {
  if (Platform.OS === "web") {
    console.warn("Call detection not available on web platform");
    return;
  }

  try {
    callDetectionSubscription = new RNCallDetection().addListener(
      "Incoming",
      (data: any) => {
        // Extract phone number from call data
        const phoneNumber = data?.phoneNumber || data?.number || "";
        
        if (phoneNumber) {
          listener.onIncomingCall({
            phoneNumber: normalizePhoneNumber(phoneNumber),
            displayName: data?.displayName || data?.name,
            callType: "incoming",
          });
        }
      }
    );

    // Listen for call end
    callDetectionSubscription?.addListener("Disconnected", () => {
      listener.onCallEnded();
    });

    console.log("Call detection started");
  } catch (error) {
    console.error("Failed to start call detection:", error);
  }
}

/**
 * Stop listening for incoming calls
 */
export function stopCallDetection(): void {
  if (callDetectionSubscription) {
    try {
      callDetectionSubscription.remove();
      callDetectionSubscription = null;
      console.log("Call detection stopped");
    } catch (error) {
      console.error("Failed to stop call detection:", error);
    }
  }
}

/**
 * Normalize phone number to standard format (remove spaces, dashes, etc.)
 */
export function normalizePhoneNumber(phoneNumber: string): string {
  return phoneNumber.replace(/\D/g, "");
}

/**
 * Format phone number for display
 */
export function formatPhoneNumber(phoneNumber: string): string {
  const cleaned = normalizePhoneNumber(phoneNumber);
  if (cleaned.length === 10) {
    return `(${cleaned.slice(0, 3)}) ${cleaned.slice(3, 6)}-${cleaned.slice(6)}`;
  }
  if (cleaned.length === 11 && cleaned[0] === "1") {
    return `+1 (${cleaned.slice(1, 4)}) ${cleaned.slice(4, 7)}-${cleaned.slice(7)}`;
  }
  return phoneNumber;
}
