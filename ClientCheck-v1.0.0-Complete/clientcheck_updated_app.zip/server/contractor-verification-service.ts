/**
 * Contractor Verification Service
 * Handles ID and license verification for contractors
 */

export interface VerificationDocument {
  type: "id" | "license" | "insurance";
  url: string;
  uploadedAt: Date;
  status: "pending" | "approved" | "rejected";
  notes?: string;
}

export interface ContractorVerification {
  userId: number;
  idVerified: boolean;
  licenseVerified: boolean;
  insuranceVerified: boolean;
  verificationBadge: boolean;
  documents: VerificationDocument[];
  submittedAt?: Date;
  approvedAt?: Date;
  rejectionReason?: string;
}

// In-memory store for demo (replace with database in production)
const verifications = new Map<number, ContractorVerification>();

/**
 * Submit verification documents
 */
export async function submitVerificationDocuments(
  userId: number,
  documents: Array<{ type: "id" | "license" | "insurance"; url: string }>
): Promise<{ success: boolean; message: string }> {
  try {
    const verification: ContractorVerification = verifications.get(userId) || {
      userId,
      idVerified: false,
      licenseVerified: false,
      insuranceVerified: false,
      verificationBadge: false,
      documents: [],
    };

    // Add new documents
    for (const doc of documents) {
      verification.documents.push({
        type: doc.type,
        url: doc.url,
        uploadedAt: new Date(),
        status: "pending",
      });
    }

    verification.submittedAt = new Date();
    verifications.set(userId, verification);

    console.log(`[Verification] User ${userId} submitted verification documents`);

    return {
      success: true,
      message: "Documents submitted for verification. Review typically takes 24-48 hours.",
    };
  } catch (error) {
    console.error("Submit verification error:", error);
    return {
      success: false,
      message: "Failed to submit verification documents",
    };
  }
}

/**
 * Get verification status
 */
export function getVerificationStatus(userId: number): ContractorVerification | null {
  return verifications.get(userId) || null;
}

/**
 * Check if contractor has verification badge
 */
export function hasVerificationBadge(userId: number): boolean {
  const verification = verifications.get(userId);
  return verification?.verificationBadge || false;
}

/**
 * Approve verification (admin only)
 */
export async function approveVerification(userId: number): Promise<boolean> {
  try {
    const verification = verifications.get(userId);
    if (!verification) return false;

    verification.idVerified = true;
    verification.licenseVerified = true;
    verification.verificationBadge = true;
    verification.approvedAt = new Date();

    verifications.set(userId, verification);

    console.log(`[Verification] User ${userId} verification approved`);

    // In production: send email notification
    return true;
  } catch (error) {
    console.error("Approve verification error:", error);
    return false;
  }
}

/**
 * Reject verification with reason (admin only)
 */
export async function rejectVerification(
  userId: number,
  reason: string
): Promise<boolean> {
  try {
    const verification = verifications.get(userId);
    if (!verification) return false;

    verification.rejectionReason = reason;
    verification.documents.forEach((doc) => {
      doc.status = "rejected";
      doc.notes = reason;
    });

    verifications.set(userId, verification);

    console.log(`[Verification] User ${userId} verification rejected: ${reason}`);

    // In production: send email notification
    return true;
  } catch (error) {
    console.error("Reject verification error:", error);
    return false;
  }
}

/**
 * Get verification badge display info
 */
export function getVerificationBadgeInfo(userId: number) {
  const verification = verifications.get(userId);

  if (!verification || !verification.verificationBadge) {
    return null;
  }

  return {
    verified: true,
    badge: "🔐 Verified Contractor",
    approvedAt: verification.approvedAt,
    documents: verification.documents.filter((d) => d.status === "approved"),
  };
}

/**
 * Get pending verifications for admin
 */
export function getPendingVerifications(): ContractorVerification[] {
  const pending: ContractorVerification[] = [];

  for (const verification of verifications.values()) {
    if (
      verification.documents.some((d) => d.status === "pending") &&
      !verification.verificationBadge
    ) {
      pending.push(verification);
    }
  }

  return pending;
}
