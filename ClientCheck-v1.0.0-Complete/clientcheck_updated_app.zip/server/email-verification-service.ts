/**
 * Email Verification Service
 * Handles email verification flow for contractors
 */

import crypto from "crypto";

export interface VerificationToken {
  token: string;
  userId: number;
  email: string;
  expiresAt: Date;
  verified: boolean;
}

// In-memory store for demo (replace with database in production)
const verificationTokens = new Map<string, VerificationToken>();

/**
 * Generate email verification token
 */
export function generateVerificationToken(userId: number, email: string): string {
  const token = crypto.randomBytes(32).toString("hex");
  const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24 hours

  verificationTokens.set(token, {
    token,
    userId,
    email,
    expiresAt,
    verified: false,
  });

  return token;
}

/**
 * Verify email token
 */
export function verifyEmailToken(token: string): boolean {
  const record = verificationTokens.get(token);

  if (!record) {
    return false;
  }

  if (new Date() > record.expiresAt) {
    verificationTokens.delete(token);
    return false;
  }

  record.verified = true;
  return true;
}

/**
 * Get verification status
 */
export function getVerificationStatus(userId: number): {
  verified: boolean;
  email?: string;
} {
  for (const record of verificationTokens.values()) {
    if (record.userId === userId && record.verified) {
      return {
        verified: true,
        email: record.email,
      };
    }
  }

  return {
    verified: false,
  };
}

/**
 * Send verification email (mock)
 */
export async function sendVerificationEmail(
  email: string,
  verificationLink: string
): Promise<boolean> {
  try {
    console.log(`[Email Verification] Sending verification email to ${email}`);
    console.log(`[Email Verification] Verification link: ${verificationLink}`);

    // In production, use email service (SendGrid, Mailgun, etc.)
    // await emailService.send({
    //   to: email,
    //   subject: "Verify your ContractorVet email",
    //   html: `Click here to verify: ${verificationLink}`
    // });

    return true;
  } catch (error) {
    console.error("Send verification email error:", error);
    return false;
  }
}

/**
 * Resend verification email
 */
export async function resendVerificationEmail(
  userId: number,
  email: string,
  baseUrl: string
): Promise<boolean> {
  try {
    const token = generateVerificationToken(userId, email);
    const verificationLink = `${baseUrl}/verify-email?token=${token}`;

    return await sendVerificationEmail(email, verificationLink);
  } catch (error) {
    console.error("Resend verification email error:", error);
    return false;
  }
}

/**
 * Check if email is verified
 */
export function isEmailVerified(userId: number): boolean {
  const status = getVerificationStatus(userId);
  return status.verified;
}
