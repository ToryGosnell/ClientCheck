/**
 * Referral Rewards Service
 * Handles referral tracking and reward distribution
 */

export interface Referral {
  id: string;
  referrerId: number;
  referredUserId?: number;
  referralCode: string;
  email: string;
  status: "pending" | "signed_up" | "active";
  createdAt: Date;
  completedAt?: Date;
}

export interface ReferralReward {
  userId: number;
  totalReferrals: number;
  completedReferrals: number;
  premiumMonthsEarned: number;
  referrals: Referral[];
}

// In-memory store for demo (replace with database in production)
const referrals = new Map<string, Referral>();
const rewards = new Map<number, ReferralReward>();

/**
 * Generate unique referral code
 */
export function generateReferralCode(userId: number): string {
  const code = `CV${userId}${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
  return code;
}

/**
 * Create referral link
 */
export function createReferralLink(userId: number, baseUrl: string): string {
  const code = generateReferralCode(userId);
  return `${baseUrl}?ref=${code}`;
}

/**
 * Track referral
 */
export async function trackReferral(
  referrerId: number,
  email: string
): Promise<{ success: boolean; referralCode: string; message: string }> {
  try {
    const referralCode = generateReferralCode(referrerId);

    const referral: Referral = {
      id: `ref_${Date.now()}`,
      referrerId,
      email,
      referralCode,
      status: "pending",
      createdAt: new Date(),
    };

    referrals.set(referralCode, referral);

    // Initialize or update rewards
    if (!rewards.has(referrerId)) {
      rewards.set(referrerId, {
        userId: referrerId,
        totalReferrals: 1,
        completedReferrals: 0,
        premiumMonthsEarned: 0,
        referrals: [referral],
      });
    } else {
      const reward = rewards.get(referrerId)!;
      reward.totalReferrals += 1;
      reward.referrals.push(referral);
    }

    console.log(`[Referral] User ${referrerId} referred ${email}`);

    return {
      success: true,
      referralCode,
      message: "Referral tracked. Your friend will receive a special signup link.",
    };
  } catch (error) {
    console.error("Track referral error:", error);
    return {
      success: false,
      referralCode: "",
      message: "Failed to track referral",
    };
  }
}

/**
 * Complete referral (when referred user signs up)
 */
export async function completeReferral(
  referralCode: string,
  referredUserId: number
): Promise<boolean> {
  try {
    const referral = referrals.get(referralCode);
    if (!referral) return false;

    referral.status = "signed_up";
    referral.referredUserId = referredUserId;
    referral.completedAt = new Date();

    // Update reward
    const reward = rewards.get(referral.referrerId);
    if (reward) {
      reward.completedReferrals += 1;
    }

    console.log(
      `[Referral] Referral ${referralCode} completed by user ${referredUserId}`
    );

    return true;
  } catch (error) {
    console.error("Complete referral error:", error);
    return false;
  }
}

/**
 * Activate referral (when referred user becomes active/paying)
 */
export async function activateReferral(referralCode: string): Promise<boolean> {
  try {
    const referral = referrals.get(referralCode);
    if (!referral) return false;

    referral.status = "active";

    // Award premium month to referrer
    const reward = rewards.get(referral.referrerId);
    if (reward) {
      reward.premiumMonthsEarned += 1;

      // Check if referrer has earned enough for free premium
      if (reward.completedReferrals >= 3) {
        console.log(
          `[Referral] User ${referral.referrerId} earned 1 month free premium (${reward.completedReferrals} referrals)`
        );
      }
    }

    return true;
  } catch (error) {
    console.error("Activate referral error:", error);
    return false;
  }
}

/**
 * Get referral rewards for user
 */
export function getReferralRewards(userId: number): ReferralReward | null {
  return rewards.get(userId) || null;
}

/**
 * Get referral status
 */
export function getReferralStatus(userId: number) {
  const reward = rewards.get(userId);

  if (!reward) {
    return {
      totalReferrals: 0,
      completedReferrals: 0,
      premiumMonthsEarned: 0,
      nextRewardAt: 3,
      referralsNeeded: 3,
    };
  }

  return {
    totalReferrals: reward.totalReferrals,
    completedReferrals: reward.completedReferrals,
    premiumMonthsEarned: reward.premiumMonthsEarned,
    nextRewardAt: 3 - reward.completedReferrals,
    referralsNeeded: Math.max(0, 3 - reward.completedReferrals),
    unlocked: reward.completedReferrals >= 3,
  };
}

/**
 * Get referral link for user
 */
export function getUserReferralLink(userId: number, baseUrl: string): string {
  const reward = rewards.get(userId);
  if (!reward || reward.referrals.length === 0) {
    return createReferralLink(userId, baseUrl);
  }

  // Return the first referral code
  return `${baseUrl}?ref=${reward.referrals[0].referralCode}`;
}

/**
 * Get all referrals for user
 */
export function getUserReferrals(userId: number): Referral[] {
  const reward = rewards.get(userId);
  return reward?.referrals || [];
}

/**
 * Send referral email invitation
 */
export async function sendReferralInvitation(
  referrerName: string,
  referrerEmail: string,
  referredEmail: string,
  referralLink: string
): Promise<boolean> {
  try {
    console.log(
      `[Referral] Sending invitation from ${referrerEmail} to ${referredEmail}`
    );
    console.log(`[Referral] Referral link: ${referralLink}`);

    // In production: use email service
    // await emailService.send({
    //   to: referredEmail,
    //   subject: `${referrerName} invited you to ContractorVet`,
    //   html: `Join ContractorVet and get 1 month free premium: ${referralLink}`
    // });

    return true;
  } catch (error) {
    console.error("Send referral invitation error:", error);
    return false;
  }
}
