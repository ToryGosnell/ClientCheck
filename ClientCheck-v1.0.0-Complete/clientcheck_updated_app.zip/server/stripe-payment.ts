import Stripe from "stripe";

const stripeSecretKey = process.env.STRIPE_SECRET_KEY;
const stripePublishableKey = process.env.STRIPE_PUBLISHABLE_KEY;

let stripe: Stripe | null = null;

if (stripeSecretKey) {
  stripe = new Stripe(stripeSecretKey);
} else {
  console.warn("[Stripe] Secret key not configured. Payments will not work.");
}

/**
 * Create a payment intent for subscription upgrade
 */
export async function createSubscriptionPaymentIntent(
  userId: number,
  userEmail: string,
  amountCents: number = 999 // $9.99 in cents
): Promise<{ clientSecret: string; publishableKey: string } | null> {
  if (!stripe) {
    console.warn("[Stripe] Stripe not configured");
    return null;
  }

  try {
    const paymentIntent = await stripe.paymentIntents.create({
      amount: amountCents,
      currency: "usd",
      payment_method_types: ["card"],
      description: `Contractor Black List Monthly Subscription - User ${userId}`,
      receipt_email: userEmail,
      metadata: {
        userId: String(userId),
        type: "subscription",
        period: "monthly",
      },
    });

    return {
      clientSecret: paymentIntent.client_secret || "",
      publishableKey: stripePublishableKey || "",
    };
  } catch (error) {
    console.error("[Stripe] Failed to create payment intent:", error);
    return null;
  }
}

/**
 * Confirm payment and create subscription
 */
export async function confirmSubscriptionPayment(
  paymentIntentId: string
): Promise<{ success: boolean; status: string }> {
  if (!stripe) {
    console.warn("[Stripe] Stripe not configured");
    return { success: false, status: "not_configured" };
  }

  try {
    const paymentIntent = await stripe.paymentIntents.retrieve(paymentIntentId);

    if (paymentIntent.status === "succeeded") {
      return { success: true, status: "succeeded" };
    } else if (paymentIntent.status === "processing") {
      return { success: false, status: "processing" };
    } else if (paymentIntent.status === "requires_payment_method") {
      return { success: false, status: "requires_payment_method" };
    } else {
      return { success: false, status: paymentIntent.status };
    }
  } catch (error) {
    console.error("[Stripe] Failed to confirm payment:", error);
    return { success: false, status: "error" };
  }
}

/**
 * Cancel a subscription
 */
export async function cancelSubscription(subscriptionId: string): Promise<boolean> {
  if (!stripe) {
    console.warn("[Stripe] Stripe not configured");
    return false;
  }

  try {
    await stripe.subscriptions.update(subscriptionId, {
      cancel_at_period_end: true,
    });
    return true;
  } catch (error) {
    console.error("[Stripe] Failed to cancel subscription:", error);
    return false;
  }
}

/**
 * Get payment method
 */
export async function getPaymentMethod(paymentMethodId: string): Promise<Stripe.PaymentMethod | null> {
  if (!stripe) {
    console.warn("[Stripe] Stripe not configured");
    return null;
  }

  try {
    return await stripe.paymentMethods.retrieve(paymentMethodId);
  } catch (error) {
    console.error("[Stripe] Failed to retrieve payment method:", error);
    return null;
  }
}

/**
 * Create a customer in Stripe
 */
export async function createStripeCustomer(
  userId: number,
  email: string,
  name: string
): Promise<string | null> {
  if (!stripe) {
    console.warn("[Stripe] Stripe not configured");
    return null;
  }

  try {
    const customer = await stripe.customers.create({
      email,
      name,
      metadata: {
        userId: String(userId),
      },
    });

    return customer.id;
  } catch (error) {
    console.error("[Stripe] Failed to create customer:", error);
    return null;
  }
}

/**
 * Get publishable key for frontend
 */
export function getStripePublishableKey(): string | null {
  return stripePublishableKey || null;
}

/**
 * Check if Stripe is configured
 */
export function isStripeConfigured(): boolean {
  return !!stripe && !!stripeSecretKey && !!stripePublishableKey;
}
