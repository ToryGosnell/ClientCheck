import Stripe from "stripe";
import { getDb } from "./db";
import { subscriptions } from "@/drizzle/schema";
import { eq } from "drizzle-orm";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || "");

const WEBHOOK_SECRET = process.env.STRIPE_WEBHOOK_SECRET || "";

/**
 * Verify Stripe webhook signature
 */
export function verifyWebhookSignature(
  body: string,
  signature: string
): Stripe.Event | null {
  if (!WEBHOOK_SECRET) {
    console.warn("[Stripe] Webhook secret not configured");
    return null;
  }

  try {
    return stripe.webhooks.constructEvent(body, signature, WEBHOOK_SECRET);
  } catch (err) {
    console.error("[Stripe] Webhook signature verification failed:", err);
    return null;
  }
}

/**
 * Handle payment_intent.succeeded event
 */
export async function handlePaymentIntentSucceeded(
  paymentIntent: Stripe.PaymentIntent
) {
  console.log("[Stripe] Payment succeeded:", paymentIntent.id);

  // Extract user ID from metadata
  const userId = paymentIntent.metadata?.userId;
  if (!userId) {
    console.warn("[Stripe] Payment intent missing userId in metadata");
    return;
  }

  // Update subscription status
  const now = new Date();
  const expiresAt = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000); // 30 days

  try {
    const db = await getDb();
    if (!db) throw new Error("Database not available");

    await db
      .update(subscriptions)
      .set({
        status: "active",
        updatedAt: now,
      })
      .where(eq(subscriptions.userId, parseInt(userId, 10)));

    console.log("[Stripe] Subscription updated for user:", userId);
  } catch (err) {
    console.error("[Stripe] Failed to update subscription:", err);
  }
}

/**
 * Handle customer.subscription.updated event
 */
export async function handleCustomerSubscriptionUpdated(
  subscription: Stripe.Subscription
) {
  console.log("[Stripe] Subscription updated:", subscription.id);

  // Extract user ID from metadata
  const userId = subscription.metadata?.userId;
  if (!userId) {
    console.warn("[Stripe] Subscription missing userId in metadata");
    return;
  }

  const status =
    subscription.status === "active" ? "active" : ("cancelled" as const);

  try {
    const db = await getDb();
    if (!db) throw new Error("Database not available");

    const periodStart = (subscription as any).current_period_start
      ? new Date((subscription as any).current_period_start * 1000)
      : new Date();
    const periodEnd = (subscription as any).current_period_end
      ? new Date((subscription as any).current_period_end * 1000)
      : new Date();

    await db
      .update(subscriptions)
      .set({
        status: status as "active" | "cancelled",
        updatedAt: new Date(),
      })
      .where(eq(subscriptions.userId, parseInt(userId, 10)));

    console.log("[Stripe] Subscription status updated:", status);
  } catch (err) {
    console.error("[Stripe] Failed to update subscription status:", err);
  }
}

/**
 * Handle customer.subscription.deleted event
 */
export async function handleCustomerSubscriptionDeleted(
  subscription: Stripe.Subscription
) {
  console.log("[Stripe] Subscription deleted:", subscription.id);

  const userId = subscription.metadata?.userId;
  if (!userId) {
    console.warn("[Stripe] Subscription missing userId in metadata");
    return;
  }

  try {
    const db = await getDb();
    if (!db) throw new Error("Database not available");

    await db
      .update(subscriptions)
      .set({
        status: "cancelled",
        updatedAt: new Date(),
      })
      .where(eq(subscriptions.userId, parseInt(userId, 10)));

    console.log("[Stripe] Subscription canceled for user:", userId);
  } catch (err) {
    console.error("[Stripe] Failed to cancel subscription:", err);
  }
}

/**
 * Main webhook event handler
 */
export async function handleStripeWebhookEvent(event: Stripe.Event) {
  switch (event.type) {
    case "payment_intent.succeeded":
      await handlePaymentIntentSucceeded(event.data.object as Stripe.PaymentIntent);
      break;

    case "customer.subscription.updated":
      await handleCustomerSubscriptionUpdated(event.data.object as Stripe.Subscription);
      break;

    case "customer.subscription.deleted":
      await handleCustomerSubscriptionDeleted(event.data.object as Stripe.Subscription);
      break;

    default:
      console.log("[Stripe] Unhandled event type:", event.type);
  }
}
